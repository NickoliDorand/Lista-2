﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA2Ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double resultado;


            Console.WriteLine("Digite a altura: ");
            a = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite a base: ");
            b = double.Parse(Console.ReadLine());

            resultado = a * b;
            Console.WriteLine(" A área é: {0}", resultado);
            Console.WriteLine();


            if (a * b >=100)
                Console.WriteLine("O terreno é grande");
           
        }
    }
}
