﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List2ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double P1;
            double P2;

            Console.WriteLine("Digite a nota da P1: ");
            P1 = double.Parse(Console.ReadLine());

            P2 = (15 - P1) / 2;
             

            if (P2 == 5)
                Console.WriteLine("Você precisa tirar nota 5 na P2 para ser aprovado");
            else
                Console.WriteLine(" Você precisa tirar nota {0} na P2 para ser aprovado", P2);
            Console.WriteLine();
            Console.WriteLine();


        }
    }
}
