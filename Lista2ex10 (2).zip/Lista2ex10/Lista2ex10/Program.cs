﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double p1;
            double p2;
            double média;

            Console.WriteLine(" Digite a nota da P1: ");
            p1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite a nota da P2:");
            p2 = double.Parse(Console.ReadLine());

            média = (p1 + (2 * p2)) / 3;

            if (média >= 5)
                Console.WriteLine("Você está aprovado!");

            else
             Console.WriteLine(" Você está reprovado :( ");
                Console.WriteLine();
                Console.WriteLine();
           

        }
    }
}
