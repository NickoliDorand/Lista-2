﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double P1;
            double c;

            Console.Write("Digite a nota da P1: ");
            P1= double.Parse(Console.ReadLine());

            
             c = 10 - P1;
            Console.WriteLine();

            if (P1 == 10)
            {
                Console.WriteLine("Você tirou a nota máxima na prova P1 e já está aprovado!");
                Console.WriteLine();
            }
            else
            Console.WriteLine("Serão necessários no mínimo {0} pontos na prova P2 ",c);
            Console.WriteLine();
            Console.WriteLine();






        }
    }
}
