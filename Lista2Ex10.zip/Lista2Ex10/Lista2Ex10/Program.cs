﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double P1;
            double P2;
            double resultado;

            Console.WriteLine("Digite o valor da nota da P1:");
            P1 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.WriteLine("Digite o valor da nota da P2:");
            P2 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            resultado = P1 + P2 / 2;

            if (resultado >= 5)

            Console.WriteLine("Aprovado");

            else Console.WriteLine("Reprovado");



        }
    }
}
