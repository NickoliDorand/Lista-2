﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA2Ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            double v3;
            Console.WriteLine("\n---------Exercício 8---------\n");
            Console.Write("Digite o 1º Valor: ");
            v1 = double.Parse(Console.ReadLine());
            Console.Write("Digite o 2º Valor: ");
            v2 = double.Parse(Console.ReadLine());
            Console.Write("Digite o 3º Valor: ");
            v3 = double.Parse(Console.ReadLine());
            Console.WriteLine("");

            v1 = Math.Pow(v1, 2);
            v2 = Math.Pow(v2, 2);
            v3 = Math.Pow(v3, 2);

            if ((v1 + v2) == v3)
            {
                Console.WriteLine("Formam um Triângulo Retângulo");
            }
            else
            {
                if ((v3 + v2) == v1)
                {
                    Console.WriteLine("Formam um Triângulo Retângulo");
                }
                else
                {
                    if ((v1 + v3) == v2)
                    {
                        Console.WriteLine("Formam um Triângulo Retângulo");
                    }
                    else
                    {
                        Console.WriteLine("Não Formam um Triângulo Retângulo");
                    }
                }
            }
        }
    }
}
