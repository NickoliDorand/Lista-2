﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LISTA2Ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double peso;
            char sexo;
            double altura;
            double relacaoPesoAltura;

            Console.WriteLine("\n---------Exercício 9---------\n");
            Console.Write("Informe o Peso (Kg): ");
            peso = double.Parse(Console.ReadLine());
            Console.Write("Informe a Sexo (Feminino (f) ou Masculino (m)): ");
            sexo = char.Parse(Console.ReadLine());
            Console.Write("Informe a altura (m): ");
            altura = double.Parse(Console.ReadLine());
            Console.WriteLine("");
            relacaoPesoAltura = peso / Math.Pow(altura, 2);
            if (sexo == 'm')
            {
                if (relacaoPesoAltura < 20)
                {
                    Console.WriteLine("Abaixo do Peso");
                }
                else
                {
                    if (relacaoPesoAltura < 25)
                    {
                        Console.WriteLine("Peso Ideal");
                    }
                    else
                    {
                        Console.WriteLine("Acima do Peso");
                    }
                }
            }
            if (sexo == 'f')
            {
                if (relacaoPesoAltura < 19)
                {
                    Console.WriteLine("Abaixo do Peso");
                }
                else
                {
                    if (relacaoPesoAltura < 24)
                    {
                        Console.WriteLine("Peso Ideal");
                    }
                    else
                    {
                        Console.WriteLine("Acima do Peso");
                    }
                }
            }
        }
    }
}
